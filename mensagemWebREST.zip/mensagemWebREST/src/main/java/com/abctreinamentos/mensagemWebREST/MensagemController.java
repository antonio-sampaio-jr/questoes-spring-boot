package com.abctreinamentos.mensagemWebREST;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MensagemController {

	@GetMapping("/")
	public ResponseEntity<String> init()
	{
		String resposta = """
				<html>
					<body>
						<h3>Mensagem da Aplicação REST API 
					</body>				
				</html>
				""";
		return new ResponseEntity<String>(resposta,HttpStatus.OK);
	}
}
