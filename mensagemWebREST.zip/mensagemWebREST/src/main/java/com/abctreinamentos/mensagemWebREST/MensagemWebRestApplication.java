package com.abctreinamentos.mensagemWebREST;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MensagemWebRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(MensagemWebRestApplication.class, args);
	}

}
