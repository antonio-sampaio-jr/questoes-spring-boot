package com.abctreinamentos.mensagemWebREST;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MensagemWebRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
