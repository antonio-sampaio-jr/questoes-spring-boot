package com.abctreinamentos.mensagemWeb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MensagemWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(MensagemWebApplication.class, args);
	}

}
