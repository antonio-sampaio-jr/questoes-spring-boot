package com.abctreinamentos.mensagemWeb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MensagemWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
