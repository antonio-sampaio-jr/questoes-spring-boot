package com.abctreinamentos.mensagem;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MensagemApplication implements CommandLineRunner {

	@Value("${message}")
	private String message;
	
	@Value("${url}")
    private String url;

	public static void main(String[] args) {
		SpringApplication.run(MensagemApplication.class, args);
		System.out.println("Primeiro Projeto Spring Boot");
	}
	
	@Override
	public void run(String... args) throws Exception {
		System.out.println("=>"+message);
		System.out.println("=>"+url);
		
	}

}
